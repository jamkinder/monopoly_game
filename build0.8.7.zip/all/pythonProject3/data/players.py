import sqlalchemy
from .db_session import SqlAlchemyBase
from flask_login import UserMixin


class Players(SqlAlchemyBase, UserMixin):
    __tablename__ = 'players'

    id = sqlalchemy.Column(sqlalchemy.Integer,nullable=False,
                           primary_key=True, autoincrement=True)
    name = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    player_id = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    win_count = sqlalchemy.Column(sqlalchemy.Integer,nullable=False)