# самый лютый проект на диком западе
import discord
from discord.ext import commands
from discord.utils import get
import sqlite3
import time
from data import db_session
from data.users import User
from data.recorder import Recorder

token = 'MTIxMTcyNjQ1MTQxNDQwNTE5MQ.G28jx8.iDnnSCUqDNHGzLgu9qaDJHOOIZ6b7rH5oorIRQ'  # токен привязки бота
gamestarted = False
log_channel = 1211755510123204608  # Дальше идут id каналов/ролей
main_channel = 1210495685204512798
bot_channel = 1212811471675985960
role_update = 1211998962815471626
lvl1role = 1212004249542594590
lvl2role = 1212004903560679424
lvl3role = 1212004960787505163
player_role = 1212400752748924998
creator_role = 1212777825451376773
game_creator = 1215003443668713563
intents = discord.Intents.default()  # получаем возможности взаимодействия бота с сервером
# и другими пользователями и другими ботами
intents.message_content = True
client = discord.Client(intents=intents)
voice = discord.VoiceChannel


@client.event
async def on_message(message):
    global gamestarted
    print(message.channel.id)
    print(type(message.channel.id))
    if message.channel.id == log_channel:
        for guild in client.guilds:
            for member in guild.members:
                print(member)
                gamestarted = False
                role = message.guild.get_role(player_role)
                await member.remove_roles(role)
                await message.author.remove_roles(role)
                role = message.guild.get_role(creator_role)
                await member.remove_roles(role)
                await message.author.remove_roles(role)
        text = message.content
        name = text[text.find(' ') + 1:text.rfind(' ')]
        id = text[text.rfind(' ') + 1:]
        req = f'{name}, {id}'
        recorder = Recorder()
        recorder.name = name
        recorder.about = id
        db_sess = db_session.create_session()
        db_sess.add(recorder)
        db_sess.commit()
    if message.content.startswith(
            "!начать") and message.channel.id == main_channel:  # проверяем на то что сообщение запуска
        role = message.guild.get_role(player_role)  # получаем роль игрока
        await message.author.add_roles(role)  # выдаем роль игрока
        if not gamestarted:  # если игра не была запущена
            try:
                channel = message.author.voice.channel  # ----
                voice = get(client.voice_clients, guild=message.guild)  # ----

                if voice and voice.is_connected():  # ----
                    await voice.move_to(channel)  # ----
                else:  # ----
                    voice = await channel.connect()  # тут мы переносим бота в войс с создателем
                channel = client.get_channel(main_channel)  # ---
                role = message.guild.get_role(creator_role)  # тут получаем роль создателя
                await message.author.add_roles(role)  # выдаем роль создателя
                start_trigger = await channel.send(
                    f"{message.author} начал игру! @everyone")  # упоминаем всех что некий игрок запустил игру
                emoji = '\N{THUMBS UP SIGN}'  # получаем бесполезное емодзи :)
                await start_trigger.add_reaction(emoji)  # показываем бесполезное емодзи :)
                gamestarted = True  # говорим что мы люто запустили катку
                for channel in message.guild.voice_channels:  # проходимся по всем голосовым каналам
                    for member in channel.members:  # проходимся по игрокам в канале
                        role = discord.utils.get(message.guild.roles, id=player_role)  # получаем роль игрока
                        role2 = discord.utils.get(message.guild.roles, id=creator_role)  # получаем роль создателя
                        if role in member.roles and role2 not in member.roles:  # проверяем что
                            # пользователь игрок но не создатель
                            await member.move_to(message.author.voice.channel)  # переносим этого игрока к создателю
            except AttributeError:  # ошибка если игрок не находился в каком-либо голосовом канале
                await message.author.send(
                    'Убедитесь, что в момент запуска игры вы находитесь в любом '
                    'голосовом канале, и у вас запущен Unity Bot, после попробуйте снова.')
        else:  # если игра запущена
            role = message.guild.get_role(player_role)  # получаем роль игрока
            await message.author.add_roles(role)  # выдаем роль игрока
            for channel in message.guild.voice_channels:  # проходися по каналам
                for member in channel.members:  # проходимся по игрокам в каналах
                    role = discord.utils.get(message.guild.roles, id=player_role)  # получаем роль игрока
                    role2 = discord.utils.get(message.guild.roles, id=creator_role)  # получаем роль создателя
                    if role in member.roles and role2 in member.roles:  # сверяем, что пользователь это создатель игры
                        await message.author.move_to(member.voice.channel)  # переносим себя к нему
    if message.content.startswith("!roleupdate") and message.channel.id == role_update:  # если мы просим обновить роль
        con = sqlite3.connect('db/blogs.db')  # обращаемся к БД
        cur = con.cursor()
        cur = cur.execute(""" SELECT id FROM records WHERE name = '{}'""".format(
            message.author.name)).fetchall()  # получаем id пользователя, который запросил обновление роли
        count = len(cur)
        con.close()
        if count >= 1 and count < 5:  # смотрим сколько побед у игрока, если от 1 и до 5 то выдаем 1
            # роль, остальные если они каким либо образом у него оказались, отбираем
            role = message.guild.get_role(lvl1role)
            await message.author.add_roles(role)
            role = message.guild.get_role(lvl2role)
            await message.author.remove_roles(role)
            role = message.guild.get_role(lvl3role)
            await message.author.remove_roles(role)
        if count >= 5 and count < 10:  # смотрим сколько побед у игрока, если от 5 и до 10 то выдаем 2
            # и 1 роль, остальные если они каким либо образом у него оказались, отбираем
            role = message.guild.get_role(lvl1role)
            await message.author.add_roles(role)
            role = message.guild.get_role(lvl2role)
            await message.author.add_roles(role)
            role = message.guild.get_role(lvl3role)
            await message.author.remove_roles(role)
        if count >= 10:  # если побед 10 и более то выдаем пользователю все роли
            role = message.guild.get_role(lvl1role)
            await message.author.add_roles(role)
            role = message.guild.get_role(lvl2role)
            await message.author.add_roles(role)
            role = message.guild.get_role(lvl3role)
            await message.author.add_roles(role)


@client.event
async def ban(ctx, name):
    ids = ()
    con = sqlite3.connect('db/blogs.db')
    cur = con.cursor()
    cur = cur.execute(""" SELECT id FROM records WHERE name = '{}'""".format(name)).fetchall()

    if len(cur) > 0:
        ids = cur[0][0]
        print(ids)
    con.close()


if __name__ == '__main__':
    db_session.global_init("db/blogs.db")
    client.run(token)


def abra():
    global client
    print(client)
    activeservers = client.guilds
    print(client.guilds)
    print('\n'.join(guild.name for guild in activeservers))
