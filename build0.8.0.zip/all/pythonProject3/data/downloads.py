import datetime
import sqlalchemy
from .db_session import SqlAlchemyBase


class Downloads(SqlAlchemyBase):
    __tablename__ = 'downloads'
    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
    count = sqlalchemy.Column(sqlalchemy.Integer)
