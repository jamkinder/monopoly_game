# -*- coding: utf-8 -*-
from flask import Flask, render_template, request, redirect, session
import asyncio
import discordbot
import sqlite3
from data import db_session
from data.users import User
from data.downloads import Downloads
from data.servers import Servers
from flask_login import LoginManager, login_user
from forms.user import RegisterForm
from flask_wtf import FlaskForm
from wtforms import PasswordField, StringField, TextAreaField, SubmitField, EmailField, BooleanField
from wtforms.validators import DataRequired
from Oauth import Oauth

app = Flask(__name__)
login_manager = LoginManager()
login_manager.init_app(app)
servers_info = []
showinfo = False
showlist = False
banmenu = False
add_menu = False
SECRET_KEY = "Yandex Lyceum"
app.config['SECRET_KEY'] = SECRET_KEY
describtion = 'Monopoly bot - дискорд бот, который позволяет множеству игроков играть одновременно ' \
              'в дискорде в любимую миллионов игру - Монополию. ' \
              '\n Чтобы все сработало нужно сделать: ' \
              '\n 1. Запустить unity приложение и нажать space либо на кнопку.' \
              '\n 2. Зайти в любой голосовой канал на сервере, к которому привязаны боты serverbot и monk.' \
              '\n 3. Запустить main.py и discordbot.py.' \
              '\n 4. написать в чат "основной" команду начала игры (!начать).' \
              '\n 5. дождаться людей, которые хотят поиграть. (для присоединения нужно зайти в любой канал того же сервера и написать !начать)' \
              '\n 6. По набору игроков, в приложении нажать на кнопку <начать игру>'

controls = 'Все управление в игре происходит через бота monk.' \
           '\n Существует 5 кнопок: ⬆️ ✔️ ❌ ➕ 💲' \
           '\n⬆️ отвечает за осуществление хода игроком (броска кубика)' \
           '\n✔️ отвечает за покупку бизнеса на клетке, на которую Вы наступили' \
           '\n❌ отвечает за отказ от покупки бизнеса' \
           '\n➕ отвечает за покупку улучшения Вашего бизнеса' \
           '\n💲 отвечает за выкуп себя из биржи'


@app.route('/')
@app.route('/home')
def base():
    import os
    current_file = os.path.realpath(__file__)
    current_directory = os.path.dirname(current_file)
    print(current_directory)
    global servers_info
    servers_info = []
    db_session.global_init("db/blogs.db")
    db_sess1 = db_session.create_session()
    downl = db_sess1.query(Downloads).first()
    count = downl.count
    con = sqlite3.connect('db/blogs.db')
    cur = con.cursor()
    cur = cur.execute(""" SELECT * FROM servers """).fetchall()
    for i in cur:
        servers_info.append(list(i))
    con.close()
    print(servers_info)
    global showinfo, showlist, banmenu
    showlist = False
    showinfo = False
    banmenu = False
    user = "Ученик Яндекс лицея"
    return render_template('base.html', count=count, discord_url=Oauth.discord_login_url,servers_info=servers_info,route=current_directory)


@app.route("/oauthlogin")
def oauthlogin():
    message = ''
    win_count = 0
    id = 0
    username = ''
    code = request.args.get("code")
    at = Oauth.get_access_token(code)
    session["token"] = at
    user = Oauth.get_user_json(at)
    print(user)
    user_name, user_id, user_avatar = user.get("username"), user.get("discriminator"), user.get("avatar")
    username = user_name
    con = sqlite3.connect('db/blogs.db')
    cur = con.cursor()
    cur = cur.execute(""" SELECT id FROM records WHERE name = '{}'""".format(username)).fetchall()
    if len(cur) > 0:
        id = cur[0][0]
        win_count = len(cur)
    con.close()
    print(id, win_count)
    print('123')

    return render_template('oauthlogin.html', user_name=user_name, id=id, win_count=win_count)


@app.route('/about')
def index():
    global showinfo, showlist, banmenu, describtion, controls
    showlist = False
    showinfo = False
    banmenu = False
    return render_template('index.html', describtion=describtion, controls=controls)


@app.route('/admin', methods=['post', 'banned', 'get', 'cancel'])
def admin():
    import os
    current_file = os.path.realpath(__file__)
    current_directory = os.path.dirname(current_file)
    username = ''
    message = ''
    cur = ()
    global showlist, banmenu,add_menu
    if request.method == 'POST':
        showlist = True
        con = sqlite3.connect('record.db')
        cur = con.cursor()
        cur = cur.execute(""" SELECT * FROM records """).fetchall()
        print(cur)
        cur = set(cur)
        cur = list(cur)
        print(cur)
        for item in cur:
            print(item)
        con.close()

    print()
    if 'ban' in request.form:
        banmenu = True
        username = request.form.get('username')
        print(username)
        asyncio.run(discordbot.ban(None, username))
    elif 'add_menu' in request.form:
        print('1313')
        add_menu = True
    elif add_menu == True and 'add_server' in request.form:
        add_menu = False
        server_name = request.form.get('server_name')
        server_logo_name = request.form.get('logo_dir')
        print(server_name,server_logo_name)
        db_session.global_init("db/blogs.db")
        server = Servers()
        server.servername = server_name
        server.serverlogo = f'\static\images\servers_logos\{server_logo_name}'
        db_sess = db_session.create_session()
        db_sess.add(server)
        db_sess.commit()


    if "cancel" in request.form:
        print('123')
        showlist = False
        add_menu = False
        banmenu = False

    return render_template('admin.html', showlist=showlist, cur=cur, username=username, banmenu=banmenu,
                           message=message,add_menu=add_menu)


@app.route('/troll', methods=['post', 'get'])
def troll():
    global showinfo, showlist, banmenu
    showlist = False
    banmenu = False
    showinfo = False
    if 'really' in request.form:
        print('123')
    if request.method == 'POST':
        return redirect("https://www.youtube.com/watch?v=dQw4w9WgXcQ", code=302)
    return render_template('prize.html')


@app.route('/download', methods=['post', 'get'])
def download():
    global showinfo, showlist, banmenu
    showlist = False
    banmenu = False
    showinfo = False
    if request.method == "POST":
        db_session.global_init("db/blogs.db")
        db_sess = db_session.create_session()
        downl = db_sess.query(Downloads).filter(Downloads.id == 1).first()
        print(download)
        downl.count += 1
        db_sess.commit()
    return render_template('download.html')


@app.route('/data', methods=['post', 'get'])
def data():
    username = ''
    global showinfo, showlist, banmenu
    banmenu = False
    showlist = False
    print(showinfo)
    message = ''
    win_count = 0
    id = 0
    if request.method == 'POST':
        showinfo = True
        username = request.form.get('username')  # Р·Р°РїСЂРѕСЃ Рє РґР°РЅРЅС‹Рј С„РѕСЂРјС‹
        con = sqlite3.connect('db/blogs.db')
        cur = con.cursor()
        cur = cur.execute(""" SELECT id FROM records WHERE name = '{}'""".format(username)).fetchall()
        if len(cur) > 0:
            id = cur[0][0]
            win_count = len(cur)
        con.close()
        print(id, win_count)

    return render_template('data.html', message=message, showinfo=showinfo, username=username, win_count=win_count,
                           id=id)


@login_manager.user_loader
def load_user(user_id):
    db_session.global_init("db/blogs.db")
    db_sess = db_session.create_session()
    return db_sess.query(User).get(user_id)


class LoginForm(FlaskForm):
    email = EmailField('Почта', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    remember_me = BooleanField('Запомнить меня')
    submit = SubmitField('Войти')


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_session.global_init('record.db')
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/admin")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Пароли не совпадают")
        db_session.global_init('record.db')
        db_sess = db_session.create_session()
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Такой пользователь уже есть")
        user = User(
            name=form.name.data,
            email=form.email.data,
            about=form.about.data
        )
        user.set_password(form.password.data)
        db_sess.add(user)
        db_sess.commit()
        return redirect('/login')
    return render_template('register.html', title='Регистрация', form=form)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1', debug=True)
