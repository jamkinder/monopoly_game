def max_difference(n, k, creatures):
    creatures.sort()
    separator = n - k
    sum_hinata = sum(creatures[:separator//2])
    sum_kenma = sum(creatures[separator//2:separator])
    max_diff = sum_hinata - sum_kenma
    return max_diff

# Чтение количества игр
t = int(input())

# Обработка каждой игры
for _ in range(t):
    n, k = map(int, input().split())
    creatures = list(map(int, input().split()))
    print(max_difference(n, k, creatures))