message = ''
    win_count = 0
    id = 0
    username = ''
    code = request.args.get("code")
    at = Oauth.get_access_token(code)
    session["token"] = at
    user = Oauth.get_user_json(at)
    print(user)
    user_name, user_id, user_avatar = user.get("username"), user.get("discriminator"), user.get("avatar")
    username = user_name
    con = sqlite3.connect('db/blogs.db')
    cur = con.cursor()
    cur = cur.execute(""" SELECT id FROM records WHERE name = '{}'""".format(username)).fetchall()
    if len(cur) > 0:
        id = cur[0][0]
        win_count = len(cur)
    con.close()
    print(id, win_count)
    print('123')

    return render_template('oauthlogin.html', user_name=user_name,id=id,win_count=win_count)