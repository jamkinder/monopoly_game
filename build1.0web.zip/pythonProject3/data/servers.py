import sqlalchemy
from .db_session import SqlAlchemyBase


class Servers(SqlAlchemyBase):
    __tablename__ = 'servers'
    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
    servername = sqlalchemy.Column(sqlalchemy.String,nullable=False)
    serverlogo = sqlalchemy.Column(sqlalchemy.Integer,nullable=False)
