# самый лютый проект на диком западе
import discord
import datetime
from discord.utils import get
import sqlite3
from data.players import Players
from data import db_session
from data import config
from data.matches import Matches
from data.recorder import Recorder

# токен привязки бота
gamestarted = False
LOG_CHANNEL = 1211755510123204608  # Дальше идут id каналов/ролей
MAIN_CHANNEL = 1210495685204512798
GAME_CHANNEL = 1210162835695603776
ROLE_UPDATE = 1211998962815471626
lvl1role = 1212004249542594590
lvl2role = 1212004903560679424
lvl3role = 1212004960787505163
PLAYER_ROLE = 1212400752748924998
CREATOR_ROLE = 1212777825451376773
GAME_CREATOR_ROLE = 1215003443668713563
GUILD_ID = 1210162834848350259
intents = discord.Intents.default()  # получаем возможности взаимодействия бота с сервером
# и другими пользователями и другими ботами
intents.message_content = True
client = discord.Client(intents=intents)
voice = discord.VoiceChannel


@client.event
async def on_message(message):
    global gamestarted
    print(message.channel.id)
    print(type(message.channel.id))
    if message.channel.id == LOG_CHANNEL:  # если получаем лог о выигранной игре
        for guild in client.guilds:  # получаем наш сервер
            for member in guild.members:  # проходимся по всем участникам
                print(member)
                gamestarted = False  # принтуем что емое игра закончилась
                role = message.guild.get_role(PLAYER_ROLE)  # снимаем все роли со всех участников сервера
                await member.remove_roles(role)
                await message.author.remove_roles(role)
                role = message.guild.get_role(CREATOR_ROLE)
                await member.remove_roles(role)
                await message.author.remove_roles(role)
        text = message.content  # все что ниже то мы логируем в таблицы
        name = text[text.find(' ') + 1:text.rfind(' ')]  # +
        id = text[text.rfind(' ') + 1:]  # +
        recorder = Recorder()  # +
        recorder.name = name  # +
        recorder.about = id  # +
        db_sess = db_session.create_session()  # обращаемся к блогам
        db_sess.add(recorder)  # добавляем в таблицу recorder
        db_sess.commit()  # +
        db_sess.close()  # +
        players = Players()  # +
        players.name = name  # +
        players.player_id = id  # +
        print(name, id)
        con = sqlite3.connect('db/blogs.db')  # обращаемся к БД
        cur = con.cursor()
        cur = cur.execute(""" SELECT name FROM players WHERE name = '{}'""".format(name)).fetchall()
        if len(cur) == 0:
            players.win_count = 0  # +
            db_sess.add(players)  # +
            db_sess.commit()  # +
        else:
            win_count = db_sess.execute(
                """SELECT win_count FROM players where name = '{}'""".format(name)).fetchall()  # +
            db_sess.execute('''UPDATE players SET win_count = ? WHERE name = ?''', (win_count + 1, name))  # +
            db_sess.commit()  # +
        db_sess.add(recorder)  # +
        db_sess.commit()  # +
        db_sess.close()  # +
        matches = Matches()  # +
        matches.created_date = datetime.datetime.now()  # +
        matches.username = name  # +
        db_sess = db_session.create_session()  # +
        db_sess.add(matches)  # добавляем в таблицу recorder
        db_sess.commit()  # +
        db_sess.close()  # +

    if message.content.startswith(
            "!начать") and message.channel.id == MAIN_CHANNEL or message.channel.id == GAME_CHANNEL:  # проверяем на то что сообщение запуска
        role = message.guild.get_role(PLAYER_ROLE)  # получаем роль игрока
        await message.author.add_roles(role)  # выдаем роль игрока
        if not gamestarted:  # если игра не была запущена
            try:
                if message.channel.id == MAIN_CHANNEL:
                    channel = client.get_channel(MAIN_CHANNEL)
                elif message.channel.id == GAME_CHANNEL:
                    channel = client.get_channel(GAME_CHANNEL)
                role = message.guild.get_role(CREATOR_ROLE)  # тут получаем роль создателя
                await message.author.add_roles(role)  # выдаем роль создателя
                gamestarted = True  # говорим что мы люто запустили катку
                for channel in message.guild.voice_channels:  # проходимся по всем голосовым каналам
                    for member in channel.members:  # проходимся по игрокам в канале
                        role = discord.utils.get(message.guild.roles, id=PLAYER_ROLE)  # получаем роль игрока
                        role2 = discord.utils.get(message.guild.roles, id=CREATOR_ROLE)  # получаем роль создателя
                        if role in member.roles and role2 not in member.roles and not member.bot:  # проверяем что
                            # пользователь игрок но не создатель
                            await member.move_to(message.author.voice.channel)  # переносим этого игрока к создателю

            except AttributeError:  # ошибка если игрок не находился в каком-либо голосовом канале
                await message.author.send(
                    'Убедитесь, что в момент запуска игры вы находитесь в любом '
                    'голосовом канале, и у вас запущен Unity Bot, после попробуйте снова.')
        else:  # если игра запущена
            role = message.guild.get_role(PLAYER_ROLE)  # получаем роль игрока
            await message.author.add_roles(role)  # выдаем роль игрока
            for channel in message.guild.voice_channels:  # проходися по каналам
                for member in channel.members:  # проходимся по игрокам в каналах
                    role = discord.utils.get(message.guild.roles, id=PLAYER_ROLE)  # получаем роль игрока
                    role2 = discord.utils.get(message.guild.roles, id=CREATOR_ROLE)  # получаем роль создателя
                    if role in member.roles and role2 in member.roles:  # сверяем, что пользователь это создатель игры
                        await message.author.move_to(member.voice.channel)  # переносим себя к нему
    if message.content.startswith("!roleupdate") and message.channel.id == ROLE_UPDATE:  # если мы просим обновить роль
        con = sqlite3.connect('db/blogs.db')  # обращаемся к БД
        cur = con.cursor()
        cur = cur.execute(""" SELECT id FROM records WHERE name = '{}'""".format(
            message.author.name)).fetchall()  # получаем id пользователя, который запросил обновление роли
        count = len(cur)
        con.close()
        if count >= 1 and count < 5:  # смотрим сколько побед у игрока, если от 1 и до 5 то выдаем 1
            # роль, остальные если они каким либо образом у него оказались, отбираем
            role = message.guild.get_role(lvl1role)
            await message.author.add_roles(role)
            role = message.guild.get_role(lvl2role)
            await message.author.remove_roles(role)
            role = message.guild.get_role(lvl3role)
            await message.author.remove_roles(role)
        if count >= 5 and count < 10:  # смотрим сколько побед у игрока, если от 5 и до 10 то выдаем 2
            # и 1 роль, остальные если они каким либо образом у него оказались, отбираем
            role = message.guild.get_role(lvl1role)
            await message.author.add_roles(role)
            role = message.guild.get_role(lvl2role)
            await message.author.add_roles(role)
            role = message.guild.get_role(lvl3role)
            await message.author.remove_roles(role)
        if count >= 10:  # если побед 10 и более то выдаем пользователю все роли
            role = message.guild.get_role(lvl1role)
            await message.author.add_roles(role)
            role = message.guild.get_role(lvl2role)
            await message.author.add_roles(role)
            role = message.guild.get_role(lvl3role)
            await message.author.add_roles(role)


if __name__ == '__main__':
    db_session.global_init("db/blogs.db")
    client.run(config.TOKEN)
