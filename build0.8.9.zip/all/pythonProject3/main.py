# -*- coding: utf-8 -*-
# самая интересная часть проекта, а интересная она потому что она даже вроде работает, хотя я не уверен
from flask import Flask, render_template, request, redirect, session, make_response
import sqlite3
from data import db_session
from data.players import Players
from data.users import User
from data.downloads import Downloads
from data.servers import Servers
from flask_login import LoginManager, login_user
from forms.user import RegisterForm
from flask_wtf import FlaskForm
from wtforms import PasswordField, SubmitField, EmailField, BooleanField
from wtforms.validators import DataRequired
from Oauth import Oauth

app = Flask(__name__)
login_manager = LoginManager()
login_manager.init_app(app)
servers_info = []
showinfo = False
showlist = False
add_menu = False
SECRET_KEY = "Yandex Lyceum"  # очень сложный секретный ключик
app.config['SECRET_KEY'] = SECRET_KEY
settings_list = [0,0]

@app.route('/')
@app.route('/home')
def base():  # мейн страничка сайта
    import os
    cookie = request.cookies.get('settings')
    show_downloads = True
    show_servers = True
    current_file = os.path.realpath(__file__)
    current_directory = os.path.dirname(current_file)  # получаем директорию проекта
    global servers_info
    servers_info = []
    db_session.global_init("db/blogs.db")
    db_sess1 = db_session.create_session()
    downl = db_sess1.query(Downloads).first()
    count = downl.count
    con = sqlite3.connect('db/blogs.db')
    cur = con.cursor()
    cur = cur.execute(""" SELECT * FROM servers """).fetchall()
    for i in cur:
        servers_info.append(list(i))  # получаем список ВСЕХ серверов которые
        # заплатили свои кровно заработанные денюжки чтобы красоваться на сайте :)
    con.close()
    print(servers_info)
    global showinfo, showlist
    showlist = False
    showinfo = False
    if cookie != None:
        if cookie[0] == "1":
            show_servers = True
        else:
            show_servers = False
        if cookie[1] == "1":
            show_downloads = True
        else:
            show_downloads = False
    return render_template('base.html', count=count, discord_url=Oauth.discord_login_url,
                           servers_info=servers_info, route=current_directory,show_servers=show_servers,show_downloads=show_downloads)


@app.route("/oauthlogin")
def oauthlogin():  # страничка входа в аккаунт ЧЕРЕЗ ДИСКОРД/сама страничка аккаунта
    # (кукки отсуствуют т.к иначе дискорду это не так уж сильно то и нравится)
    total_level = 0
    last_matches = False
    last_matches_list = []
    win_count = 0
    id = 0
    code = request.args.get("code")
    at = Oauth.get_access_token(code)
    session["token"] = at
    user = Oauth.get_user_json(at)  # получаем юзера
    print(user)
    user_name, user_id, user_avatar = user.get("username"), user.get("discriminator"), user.get("avatar")
    username = user_name
    con = sqlite3.connect('db/blogs.db')
    cur = con.cursor()
    cur = cur.execute(
        """ SELECT player_id,win_count FROM players WHERE name = '{}'""".format(username)).fetchall()  # получаем всех пользователей
    # важно чтобы у них была какая либо статистика
    if len(cur) > 0:
        id = cur[0][0]
        win_count = cur[0][1]
        if win_count >= 1 and win_count < 5:
            total_level = 1
        elif win_count >= 5 and win_count < 10:
            total_level = 2
        elif win_count >= 10:
            total_level = 3

    else:
        id = 'NO USER'
        win_count = 'FOUND'

    con.close()
    print(id, win_count)
    print('123')
    if "last_matches" in request.form:  # если мы нажали на кнопку просмотра последних матчей
        last_matches = True
        con = sqlite3.connect('db/blogs.db')
        cur = con.cursor()
        cur = cur.execute(""" SELECT * FROM matches ORDER BY id DESC LIMIT 5 """).fetchall()  # получаем последние 5 игр
        for i in cur:  # проходимся по последним матчам
            last_matches_list.append(list(i))
    if last_matches_list == []:
        last_matches_list = 'NO MATCHES'

    return render_template('oauthlogin.html', user_name=user_name, id=id, win_count=win_count,
                           last_matches=last_matches, last_matches_list=last_matches_list,total_level=total_level)


@app.route('/about')
def index():  # страничка с информацией о приложеньке
    global showinfo, showlist, describtion, controls
    showlist = False
    showinfo = False
    return render_template('index.html')
@app.route('/settings',methods=['POST','GET'])
def settings():  # страничка с информацией о приложеньке
    cookie_string = ''
    global showinfo, showlist, describtion, controls
    showlist = False
    showinfo = False
    if request.method == 'POST':
        global settings_list
        for elem in request.form:
            if elem == 'show_servers':
                settings_list[0] = 1
            elif elem == 'show_downloads':
                settings_list[1] = 1
        if 'show_servers' not in request.form:
            settings_list[0] = 0
        if 'show_downloads' not in request.form:
            settings_list[1] = 0
        res = make_response("Setting a cookie")
        for elem in settings_list:
            cookie_string += str(elem)
        res.set_cookie('settings',cookie_string, max_age=60 * 60 * 24 * 365 * 2)
        return res


    return render_template('settings.html')

@app.route('/admin', methods=['post', 'get'])
def admin():  # страничка админ панели
    last_matches = False
    last_matches_list = []
    username = ''
    message = ''
    cur = ()
    global showlist, add_menu
    if request.method == 'POST':
        showlist = True
        con = sqlite3.connect('record.db')
        cur = con.cursor()
        cur = cur.execute(""" SELECT * FROM records """).fetchall()
        cur = set(cur)
        cur = list(cur)
        con.close()

    if 'add_menu' in request.form:  # если мы хотим добавить сервер то открываем менюшку
        print('1313')
        add_menu = True
    elif add_menu == True and 'add_server' in request.form:  # если менюшка открыта и мы все же решили добавить сервер
        add_menu = False
        server_name = request.form.get('server_name')
        server_logo_name = request.form.get('logo_dir')
        print(server_name, server_logo_name)
        db_session.global_init("db/blogs.db")
        server = Servers()
        server.servername = server_name
        server.serverlogo = f'\static\images\servers_logos\{server_logo_name}'
        db_sess = db_session.create_session()
        db_sess.add(server)
        db_sess.commit()
        db_sess.close()  # добавляем из указанных данных информацию в таблицу и сохраняем ее
    elif 'playerlist' in request.form:  # если мы хотим посмотреть список всех игроков
        db_sess = sqlite3.connect("db/blogs.db")
        cur = db_sess.execute("""SELECT * from players""").fetchall()
        if cur == None:
            cur = 'ПУСТО'
        elif len(cur) <= 0:
            cur = 'ПУСТО'
        showlist = True
    if "cancel" in request.form:
        showlist = False
        add_menu = False
    if "last_matches" in request.form:
        last_matches = True
        showlist = False
        con = sqlite3.connect('db/blogs.db')
        cur = con.cursor()
        cur = cur.execute(""" SELECT * FROM matches """).fetchall()
        for i in cur:
            last_matches_list.append(list(i))
    if last_matches_list == []:
        last_matches_list = 'NO MATCHES'
    return render_template('admin.html', showlist=showlist, cur=cur, username=username,
                           message=message, add_menu=add_menu, last_matches=last_matches,
                           last_matches_list=last_matches_list)


@app.route('/troll', methods=['post', 'get'])
def troll():  # тролл страничка :)
    global showinfo, showlist
    showlist = False
    showinfo = False
    if 'really' in request.form:
        print('123')
    if request.method == 'POST':
        return redirect("https://www.youtube.com/watch?v=dQw4w9WgXcQ", code=302)
    return render_template('prize.html')


@app.route('/download', methods=['post', 'get'])
def download():  # страничка с загрузкой приложеньки
    global showinfo, showlist
    showlist = False
    showinfo = False
    if request.method == "POST":
        db_session.global_init("db/blogs.db")
        db_sess = db_session.create_session()
        downl = db_sess.query(Downloads).filter(Downloads.id == 1).first()  # добавляем кол-во скаченных в таблицу
        print(download)
        downl.count += 1
        db_sess.commit()
        db_sess.close()
    return render_template('download.html')


@app.route('/data', methods=['post', 'get'])
def data():  # страница с информацией о каждом участнике
    global showinfo, showlist
    username = ''
    message = ''
    showlist = False
    win_count = 0
    id = 0
    if request.method == 'POST':
        showinfo = True
        username = request.form.get('username')
        con = sqlite3.connect('db/blogs.db')
        cur = con.cursor()
        cur = cur.execute(""" SELECT player_id,win_count FROM players WHERE name = '{}'""".format(username)).fetchall()
        if len(cur) > 0:
            id = cur[0][0]
            win_count = cur[0][1]
        else:
            id = 'USER'
            win_count = 'NOT FOUND'
        con.close()


    return render_template('data.html', message=message, showinfo=showinfo, username=username, win_count=win_count,
                           id=id)


@login_manager.user_loader
def load_user(user_id):
    db_session.global_init("db/blogs.db")
    db_sess = db_session.create_session()
    return db_sess.query(User).get(user_id)


class LoginForm(FlaskForm):
    email = EmailField('Почта', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    remember_me = BooleanField('Запомнить меня')
    submit = SubmitField('Войти')


@app.route('/login', methods=['GET', 'POST'])
def login():  # менюшка входа в аккаунт администратора
    form = LoginForm()
    if form.validate_on_submit():  # если мы отправили форму на проверку
        db_session.global_init('record.db')
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.email == form.email.data).first()  # получаем юзера
        if user and user.check_password(form.password.data):  # если все ок
            login_user(user, remember=form.remember_me.data)
            return redirect("/admin")  # редиректим на страницу админа
        return render_template('login.html',  # иначе выдаем ошибку
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Авторизация',
                           form=form)  # ну или иначе просто отрисовываем эту страницу


@app.route('/register', methods=['GET', 'POST'])
def reqister():  # менюшка регистрации (В НЕЕ НЕЛЬЗЯ ЗАЙТИ С ПОМОЩЬЮ КНОПОК САЙТА)
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Пароли не совпадают")
        db_session.global_init('record.db')
        db_sess = db_session.create_session()
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Такой пользователь уже есть")
        user = User(
            name=form.name.data,
            email=form.email.data,
            about=form.about.data
        )
        user.set_password(form.password.data)
        db_sess.add(user)
        db_sess.commit()
        db_sess.close()
        return redirect('/login')
    return render_template('register.html', title='Регистрация', form=form)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1', debug=True)
