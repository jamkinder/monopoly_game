TOKEN = "MTIxMDE3OTE4NjA1NzI4MTU4Ng.Gm8IJ9.Al2cqhvfA_44G5BVl9N_0rCHQLPLBjCos8baBw"
CLIENT_SECRET = "FNQkBa6EZHmVa3xQs_EHdX-1WHRMO5NQ"
REDIRECT_URI = "http://localhost:8080/oauth/callback"
OAUTH_URL = f'https://discord.com/oauth2/authorize?client_id=1211726451414405191&response_type=code&redirect_uri=http%3A%2F%2Flocalhost%3A8080%2Foauthlogin&scope=identify+guilds+email'
