import json
from sys import stdin
answers = stdin.read().splitlines()
res = 0
with open('scoring.json') as file:
    data = json.loads(file.read())
    for i, ans in enumerate(answers):
        if ans == 'ok':
            for a in data['scoring']:
                if i + 1 in a['required_tests']:
                    res += a['points'] // len(a['required_tests'])
    print(res)