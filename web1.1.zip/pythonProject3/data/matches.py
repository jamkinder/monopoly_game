import sqlalchemy
from .db_session import SqlAlchemyBase
from flask_login import UserMixin
import datetime


class Matches(SqlAlchemyBase, UserMixin):
    __tablename__ = 'matches'

    id = sqlalchemy.Column(sqlalchemy.Integer, nullable=False,
                           primary_key=True, autoincrement=True)
    created_date = sqlalchemy.Column(sqlalchemy.DateTime,
                                     default=datetime.datetime.now)
    username = sqlalchemy.Column(sqlalchemy.String, nullable=False)
